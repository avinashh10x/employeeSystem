const awsServerlessExpress = require('aws-serverless-express');
const app = require('./index'); // Adjust the path if your app is in a different file
const server = awsServerlessExpress.createServer(app);

exports.handler = (event, context) => {
  awsServerlessExpress.proxy(server, event, context);
};
